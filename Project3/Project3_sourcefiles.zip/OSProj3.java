import java.io.IOException;

/**
 *
 * @author huynh
 */
public class OSProj3 {
   
    public static void main(String[] args) throws IOException {
        UI menu = new UI();
        menu.runInterface();
    }    
}
